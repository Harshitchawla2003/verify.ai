import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  FileText, 
  Image, 
  Video, 
  Link, 
  Upload, 
  Loader2, 
  CheckCircle, 
  AlertTriangle,
  Brain,
  Eye,
  BarChart3,
  TrendingUp,
  Clock,
  ExternalLink
} from "lucide-react";
import { analyzeTextContent, verifyURL } from "@/lib/api/factCheck";
import { analyzeImage, analyzeVideo } from "@/lib/api/mediaAnalysis";
import type { VerificationResult } from "@/lib/api/factCheck";

const Verify = () => {
  const [activeTab, setActiveTab] = useState("text");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<VerificationResult | null>(null);
  const [inputText, setInputText] = useState("");
  const [inputUrl, setInputUrl] = useState("");
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [selectedVideoFile, setSelectedVideoFile] = useState<File | null>(null);
  const { toast } = useToast();

  const analyzeContent = async () => {
    setIsAnalyzing(true);
    setResult(null);

    try {
      let analysisResult: VerificationResult;

      switch (activeTab) {
        case "text":
          if (!inputText.trim()) {
            toast({
              title: "Error",
              description: "Please enter text to analyze",
              variant: "destructive",
            });
            setIsAnalyzing(false);
            return;
          }
          analysisResult = await analyzeTextContent(inputText);
          break;

        case "url":
          if (!inputUrl.trim()) {
            toast({
              title: "Error",
              description: "Please enter a URL to verify",
              variant: "destructive",
            });
            setIsAnalyzing(false);
            return;
          }
          analysisResult = await verifyURL(inputUrl);
          break;

        case "image":
          if (!selectedImageFile) {
            toast({
              title: "Error",
              description: "Please select an image to analyze",
              variant: "destructive",
            });
            setIsAnalyzing(false);
            return;
          }
          analysisResult = await analyzeImage(selectedImageFile);
          break;

        case "video":
          if (!selectedVideoFile) {
            toast({
              title: "Error",
              description: "Please select a video to analyze",
              variant: "destructive",
            });
            setIsAnalyzing(false);
            return;
          }
          analysisResult = await analyzeVideo(selectedVideoFile);
          break;

        default:
          throw new Error("Invalid content type");
      }

      setResult(analysisResult);
      toast({
        title: "Analysis Complete",
        description: "Content has been verified successfully",
      });
    } catch (error) {
      console.error("Analysis error:", error);
      toast({
        title: "Analysis Failed",
        description: error instanceof Error ? error.message : "An error occurred during analysis",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid File",
          description: "Please select an image file",
          variant: "destructive",
        });
        return;
      }
      setSelectedImageFile(file);
      toast({
        title: "Image Selected",
        description: `${file.name} ready for analysis`,
      });
    }
  };

  const handleVideoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('video/')) {
        toast({
          title: "Invalid File",
          description: "Please select a video file",
          variant: "destructive",
        });
        return;
      }
      setSelectedVideoFile(file);
      toast({
        title: "Video Selected",
        description: `${file.name} ready for analysis`,
      });
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-12 bg-gradient-to-br from-background to-muted/30">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6">
            <span className="text-gradient-primary">Verify Content</span> Now
          </h1>
          <p className="text-xl text-muted-foreground">
            Upload or paste content to analyze for authenticity using our advanced AI detection system
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {/* Input Panel */}
          <div className="lg:col-span-2">
            <Card className="glass-card shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-primary" />
                  Content Input
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-4 mb-6">
                    <TabsTrigger value="text" className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Text
                    </TabsTrigger>
                    <TabsTrigger value="image" className="flex items-center gap-2">
                      <Image className="w-4 h-4" />
                      Image
                    </TabsTrigger>
                    <TabsTrigger value="video" className="flex items-center gap-2">
                      <Video className="w-4 h-4" />
                      Video
                    </TabsTrigger>
                    <TabsTrigger value="url" className="flex items-center gap-2">
                      <Link className="w-4 h-4" />
                      URL
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="text" className="space-y-4">
                    <Textarea
                      placeholder="Paste the text content you want to verify..."
                      className="min-h-[200px] resize-none"
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                    />
                  </TabsContent>

                  <TabsContent value="image" className="space-y-4">
                    <div className="border-2 border-dashed border-border rounded-lg p-12 text-center hover:border-primary/50 transition-colors">
                      <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                      <p className="text-muted-foreground mb-2">
                        {selectedImageFile ? selectedImageFile.name : "Drag & drop an image or"}
                      </p>
                      <label htmlFor="image-upload">
                        <Button variant="outline" type="button" onClick={() => document.getElementById('image-upload')?.click()}>
                          Choose File
                        </Button>
                      </label>
                      <input
                        id="image-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageUpload}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="video" className="space-y-4">
                    <div className="border-2 border-dashed border-border rounded-lg p-12 text-center hover:border-primary/50 transition-colors">
                      <Video className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                      <p className="text-muted-foreground mb-2">
                        {selectedVideoFile ? selectedVideoFile.name : "Drag & drop a video or"}
                      </p>
                      <label htmlFor="video-upload">
                        <Button variant="outline" type="button" onClick={() => document.getElementById('video-upload')?.click()}>
                          Choose File
                        </Button>
                      </label>
                      <input
                        id="video-upload"
                        type="file"
                        accept="video/*"
                        className="hidden"
                        onChange={handleVideoUpload}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="url" className="space-y-4">
                    <Input
                      placeholder="Enter URL to verify (e.g., news article, social media post)"
                      value={inputUrl}
                      onChange={(e) => setInputUrl(e.target.value)}
                    />
                  </TabsContent>

                  <Button 
                    onClick={analyzeContent}
                    disabled={isAnalyzing || (
                      (activeTab === 'text' && !inputText) ||
                      (activeTab === 'url' && !inputUrl) ||
                      (activeTab === 'image' && !selectedImageFile) ||
                      (activeTab === 'video' && !selectedVideoFile)
                    )}
                    className="w-full mt-6"
                    variant="hero"
                    size="lg"
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Analyzing Content...
                      </>
                    ) : (
                      <>
                        <Eye className="w-5 h-5" />
                        Analyze Content
                      </>
                    )}
                  </Button>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Results Panel */}
          <div className="space-y-6">
            {/* Analysis Progress */}
            {isAnalyzing && (
              <Card className="glass-card shadow-card">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-5 h-5 animate-spin text-primary" />
                      <span className="font-semibold">AI Analysis in Progress</span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Processing content...</span>
                        <span>85%</span>
                      </div>
                      <Progress value={85} className="w-full" />
                    </div>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <p>✓ Content parsed</p>
                      <p>✓ Running ML models</p>
                      <p className="text-primary">→ Generating insights...</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Results */}
            {result && !isAnalyzing && (
              <>
                {/* Main Result */}
                <Card className={`glass-card shadow-card border-2 ${result.isReal ? 'border-success/30' : 'border-destructive/30'}`}>
                  <CardContent className="p-6">
                    <div className="text-center space-y-4">
                      {result.isReal ? (
                        <CheckCircle className="w-16 h-16 mx-auto text-success" />
                      ) : (
                        <AlertTriangle className="w-16 h-16 mx-auto text-destructive" />
                      )}
                      
                      <div>
                        <h3 className={`text-2xl font-bold ${result.isReal ? 'text-success' : 'text-destructive'}`}>
                          {result.isReal ? 'LIKELY REAL' : 'LIKELY FAKE'}
                        </h3>
                        <p className="text-muted-foreground">
                          Confidence: {result.confidence.toFixed(1)}%
                        </p>
                      </div>

                      <div className="w-full bg-muted rounded-full h-3">
                        <div 
                          className={`h-3 rounded-full bg-gradient-to-r ${result.isReal ? 'from-success to-success-glow' : 'from-destructive to-destructive-glow'}`}
                          style={{ width: `${result.confidence}%` }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Detailed Metrics */}
                <Card className="glass-card shadow-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="w-5 h-5" />
                      Analysis Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm">Credibility Score</span>
                        <span className="text-sm font-semibold">{result.credibilityScore.toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-primary to-primary-glow h-2 rounded-full"
                          style={{ width: `${result.credibilityScore}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm">Source Reliability</span>
                        <span className="text-sm font-semibold">{result.sourceReliability.toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-secondary to-secondary-glow h-2 rounded-full"
                          style={{ width: `${result.sourceReliability}%` }}
                        />
                      </div>
                    </div>

                    <div className="pt-4 border-t border-border/50 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Processing Time</span>
                        <span className="text-sm font-semibold flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {result.processingTime}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Sentiment</span>
                        <span className={`text-sm font-semibold capitalize ${
                          result.sentiment === 'positive' ? 'text-success' : 
                          result.sentiment === 'negative' ? 'text-destructive' : 'text-muted-foreground'
                        }`}>
                          {result.sentiment}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Key Highlights */}
                <Card className="glass-card shadow-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5" />
                      Key Findings
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {result.explanation && (
                        <p className="text-sm text-muted-foreground mb-3 pb-3 border-b border-border/50">
                          {result.explanation}
                        </p>
                      )}
                      {result.highlights.map((highlight, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <div className={`w-2 h-2 rounded-full ${
                            result.isReal ? 'bg-success' : 'bg-destructive'
                          }`} />
                          <span className="capitalize">{highlight}</span>
                        </div>
                      ))}
                      
                      {result.factChecks && result.factChecks.length > 0 && (
                        <div className="mt-4 pt-3 border-t border-border/50">
                          <p className="text-xs font-semibold mb-2">Fact-Check Sources:</p>
                          {result.factChecks.slice(0, 3).map((fc, idx) => (
                            <div key={idx} className="mb-2">
                              {fc.claimReview?.slice(0, 2).map((review, ridx) => (
                                <a
                                  key={ridx}
                                  href={review.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center gap-1 text-xs text-primary hover:underline"
                                >
                                  <ExternalLink className="w-3 h-3" />
                                  {review.publisher}: {review.textualRating}
                                </a>
                              ))}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </>
            )}

            {/* Initial State */}
            {!result && !isAnalyzing && (
              <Card className="glass-card shadow-card">
                <CardContent className="p-6 text-center">
                  <Brain className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="font-semibold mb-2">Ready to Analyze</h3>
                  <p className="text-sm text-muted-foreground">
                    Enter content and click "Analyze Content" to see detailed verification results
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Verify;