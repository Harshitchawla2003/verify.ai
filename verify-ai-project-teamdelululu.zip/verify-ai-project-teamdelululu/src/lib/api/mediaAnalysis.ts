import { GoogleGenerativeAI } from '@google/generative-ai';

const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

export interface MediaAnalysisResult {
  isReal: boolean;
  confidence: number;
  credibilityScore: number;
  sentiment: 'positive' | 'negative' | 'neutral';
  highlights: string[];
  sourceReliability: number;
  processingTime: string;
  description: string;
  manipulationIndicators: string[];
}

// Convert file to base64 (without data URL prefix)
async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64 = (reader.result as string).split(',')[1];
      resolve(base64);
    };
    reader.onerror = error => reject(error);
  });
}

// Convert file to Gemini format
async function fileToGenerativePart(file: File): Promise<{ inlineData: { data: string; mimeType: string } }> {
  const base64Data = await fileToBase64(file);
  return {
    inlineData: {
      data: base64Data,
      mimeType: file.type,
    },
  };
}

// Analyze image using Google Gemini API
export async function analyzeImage(file: File): Promise<MediaAnalysisResult> {
  const startTime = Date.now();

  if (!GEMINI_API_KEY) {
    // Fallback analysis without API
    return fallbackImageAnalysis(file, startTime);
  }

  try {
    const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
    // Use gemini-2.5-flash - supports multimodal (image) analysis
    const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });

    const imagePart = await fileToGenerativePart(file);

    const prompt = `Analyze this image for authenticity and potential manipulation. Provide your analysis in JSON format with the following keys:
- isAuthentic (boolean): whether the image appears authentic or manipulated
- confidence (number 0-100): confidence level in your assessment
- manipulationSigns (array of strings): any signs of manipulation or editing detected
- description (string): brief description of what the image shows
- redFlags (array of strings): any concerning elements or red flags

Respond ONLY with valid JSON, no additional text.`;

    const result = await model.generateContent([prompt, imagePart]);
    const response = await result.response;
    const text = response.text();
    
    // Extract JSON from response (handle markdown code blocks)
    let jsonText = text.trim();
    if (jsonText.startsWith('```json')) {
      jsonText = jsonText.replace(/```json\n?/g, '').replace(/```\n?/g, '');
    } else if (jsonText.startsWith('```')) {
      jsonText = jsonText.replace(/```\n?/g, '');
    }
    
    const analysisResult = JSON.parse(jsonText);

    const processingTime = ((Date.now() - startTime) / 1000).toFixed(2) + 's';

    return {
      isReal: analysisResult.isAuthentic,
      confidence: analysisResult.confidence,
      credibilityScore: analysisResult.isAuthentic ? analysisResult.confidence : 100 - analysisResult.confidence,
      sentiment: 'neutral',
      highlights: analysisResult.isAuthentic
        ? ['Appears authentic', 'No obvious manipulation', 'Consistent metadata']
        : ['Possible manipulation detected', 'Inconsistencies found', 'Requires verification'],
      sourceReliability: analysisResult.confidence,
      processingTime,
      description: analysisResult.description,
      manipulationIndicators: analysisResult.manipulationSigns || analysisResult.redFlags || [],
    };
  } catch (error) {
    console.error('Error analyzing image with Gemini:', error);
    return fallbackImageAnalysis(file, startTime);
  }
}

// Analyze video using Google Gemini API
export async function analyzeVideo(file: File): Promise<MediaAnalysisResult> {
  const startTime = Date.now();

  if (!GEMINI_API_KEY) {
    return fallbackVideoAnalysis(file, startTime);
  }

  try {
    // For video, we'll extract the first frame and analyze it
    // Gemini 1.5 supports video but for simplicity we'll analyze a key frame
    const videoUrl = URL.createObjectURL(file);
    
    // Create a video element to extract frame
    const video = document.createElement('video');
    video.src = videoUrl;
    
    return new Promise((resolve) => {
      video.onloadedmetadata = async () => {
        video.currentTime = 1; // Get frame at 1 second
        
        video.onseeked = async () => {
          const canvas = document.createElement('canvas');
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          const ctx = canvas.getContext('2d');
          
          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            
            // Convert canvas to blob
            canvas.toBlob(async (blob) => {
              if (!blob) {
                URL.revokeObjectURL(videoUrl);
                resolve(fallbackVideoAnalysis(file, startTime));
                return;
              }

              try {
                const frameFile = new File([blob], 'frame.jpg', { type: 'image/jpeg' });
                const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
                const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

                const imagePart = await fileToGenerativePart(frameFile);

                const prompt = `Analyze this video frame for authenticity and potential deepfake/manipulation. Provide your analysis in JSON format with the following keys:
- isAuthentic (boolean): whether the video appears authentic or manipulated
- confidence (number 0-100): confidence level in your assessment
- manipulationSigns (array of strings): any signs of deepfake or video manipulation
- description (string): brief description of what you see
- suspiciousElements (array of strings): any suspicious elements detected

Respond ONLY with valid JSON, no additional text.`;

                const result = await model.generateContent([prompt, imagePart]);
                const response = await result.response;
                const text = response.text();
                
                // Extract JSON from response
                let jsonText = text.trim();
                if (jsonText.startsWith('```json')) {
                  jsonText = jsonText.replace(/```json\n?/g, '').replace(/```\n?/g, '');
                } else if (jsonText.startsWith('```')) {
                  jsonText = jsonText.replace(/```\n?/g, '');
                }
                
                const analysisResult = JSON.parse(jsonText);
                const processingTime = ((Date.now() - startTime) / 1000).toFixed(2) + 's';

                URL.revokeObjectURL(videoUrl);

                resolve({
                  isReal: analysisResult.isAuthentic,
                  confidence: analysisResult.confidence,
                  credibilityScore: analysisResult.isAuthentic ? analysisResult.confidence : 100 - analysisResult.confidence,
                  sentiment: 'neutral',
                  highlights: analysisResult.isAuthentic
                    ? ['Appears authentic', 'No deepfake indicators', 'Natural video quality']
                    : ['Possible manipulation', 'Deepfake indicators detected', 'Further analysis needed'],
                  sourceReliability: analysisResult.confidence,
                  processingTime,
                  description: analysisResult.description,
                  manipulationIndicators: analysisResult.manipulationSigns || analysisResult.suspiciousElements || [],
                });
              } catch (error) {
                console.error('Error analyzing video frame with Gemini:', error);
                URL.revokeObjectURL(videoUrl);
                resolve(fallbackVideoAnalysis(file, startTime));
              }
            }, 'image/jpeg', 0.95);
          } else {
            URL.revokeObjectURL(videoUrl);
            resolve(fallbackVideoAnalysis(file, startTime));
          }
        };
      };

      video.onerror = () => {
        URL.revokeObjectURL(videoUrl);
        resolve(fallbackVideoAnalysis(file, startTime));
      };
    });
  } catch (error) {
    console.error('Error analyzing video:', error);
    return fallbackVideoAnalysis(file, startTime);
  }
}

// Fallback analysis when API is not available
function fallbackImageAnalysis(file: File, startTime: number): MediaAnalysisResult {
  const processingTime = ((Date.now() - startTime) / 1000).toFixed(2) + 's';

  // Basic file analysis
  const fileSize = file.size;
  const fileName = file.name;
  
  return {
    isReal: true,
    confidence: 60,
    credibilityScore: 55,
    sentiment: 'neutral',
    highlights: [
      'API key not configured',
      'Limited analysis available',
      'Manual verification recommended',
    ],
    sourceReliability: 50,
    processingTime,
    description: `Image file: ${fileName} (${(fileSize / 1024).toFixed(2)} KB). Full analysis requires Google Gemini API key configuration.`,
    manipulationIndicators: [
      'Advanced analysis not available',
      'Configure VITE_GEMINI_API_KEY for detailed analysis',
    ],
  };
}

function fallbackVideoAnalysis(file: File, startTime: number): MediaAnalysisResult {
  const processingTime = ((Date.now() - startTime) / 1000).toFixed(2) + 's';

  const fileSize = file.size;
  const fileName = file.name;

  return {
    isReal: true,
    confidence: 55,
    credibilityScore: 50,
    sentiment: 'neutral',
    highlights: [
      'API key not configured',
      'Basic metadata analysis only',
      'Professional verification recommended',
    ],
    sourceReliability: 45,
    processingTime,
    description: `Video file: ${fileName} (${(fileSize / 1024 / 1024).toFixed(2)} MB). Full deepfake detection requires Google Gemini API key configuration.`,
    manipulationIndicators: [
      'Advanced deepfake detection not available',
      'Configure VITE_GEMINI_API_KEY for AI-powered analysis',
    ],
  };
}
