import axios from 'axios';
import { GoogleGenerativeAI } from '@google/generative-ai';

const FACT_CHECK_API_KEY = import.meta.env.VITE_FACT_CHECK_API_KEY;
const NEWS_API_KEY = import.meta.env.VITE_NEWS_API_KEY;
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

// Google Fact Check Tools API
const FACT_CHECK_API_URL = 'https://factchecktools.googleapis.com/v1alpha1/claims:search';
const NEWS_API_URL = 'https://newsapi.org/v2/everything';

export interface FactCheckResult {
  text: string;
  claimant: string;
  claimDate: string;
  claimReview: Array<{
    publisher: string;
    url: string;
    title: string;
    textualRating: string;
    languageCode: string;
  }>;
}

export interface NewsVerification {
  articles: Array<{
    source: string;
    title: string;
    description: string;
    url: string;
    publishedAt: string;
  }>;
  totalResults: number;
}

export interface GeminiFactCheckResult {
  isTrue: boolean;
  confidence: number;
  explanation: string;
  sources: string[];
  category: 'true' | 'false' | 'misleading' | 'unverified';
}

export interface VerificationResult {
  isReal: boolean;
  confidence: number;
  credibilityScore: number;
  sentiment: 'positive' | 'negative' | 'neutral';
  highlights: string[];
  sourceReliability: number;
  processingTime: string;
  factChecks?: FactCheckResult[];
  relatedArticles?: NewsVerification;
  explanation?: string;
}

// Fact check using Google Fact Check Tools API (blocked for public use)
export async function checkFactWithGoogle(query: string): Promise<FactCheckResult[]> {
  if (!FACT_CHECK_API_KEY) {
    console.warn('Google Fact Check API key not configured');
    return [];
  }

  try {
    const response = await axios.get(FACT_CHECK_API_URL, {
      params: {
        key: FACT_CHECK_API_KEY,
        query: query,
        languageCode: 'en',
      },
    });

    if (response.data.claims) {
      return response.data.claims;
    }
    return [];
  } catch (error: any) {
    if (error.response?.status === 403) {
      const errorData = error.response?.data?.error;
      if (errorData?.details?.some((d: any) => d.reason === 'API_KEY_SERVICE_BLOCKED')) {
        console.warn('ℹ️ Google Fact Check API is not available for public API key access.');
        console.warn('ℹ️ Using alternative verification methods (NewsAPI + Gemini AI).');
      } else {
        console.warn('Google Fact Check API Error: API access restricted.');
        console.warn('Using alternative verification methods instead.');
      }
    } else {
      console.error('Error checking facts with Google:', error);
    }
    return [];
  }
}

// Fact check using Gemini AI (hybrid approach)
export async function checkFactWithGemini(query: string): Promise<GeminiFactCheckResult | null> {
  if (!GEMINI_API_KEY) {
    console.warn('Gemini API key not configured - skipping AI fact verification');
    return null;
  }

  try {
    const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });

    const prompt = `You are a fact-checking expert. Verify this claim: "${query}"

Based on your knowledge and reasoning, provide your response in JSON format with these exact keys:
{
  "isTrue": boolean (true if factually accurate, false if not),
  "confidence": number (0-100, how confident you are),
  "explanation": "2-3 sentence explanation of your findings",
  "sources": ["list of relevant source types you considered"],
  "category": "true" or "false" or "misleading" or "unverified"
}

Guidelines:
- Well-known conspiracy theories or pseudoscience = false with high confidence
- Established scientific facts = true with high confidence  
- Conflicting information or limited data = unverified
- Mention types of sources (scientific consensus, news reports, historical records)

Respond ONLY with valid JSON, no additional text.`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    // Extract JSON from response (handle markdown code blocks)
    let jsonText = text.trim();
    if (jsonText.startsWith('```json')) {
      jsonText = jsonText.replace(/```json\n?/g, '').replace(/```\n?/g, '');
    } else if (jsonText.startsWith('```')) {
      jsonText = jsonText.replace(/```\n?/g, '');
    }

    const geminiResult = JSON.parse(jsonText);

    console.log('✨ Gemini fact-check result:', geminiResult);

    return {
      isTrue: geminiResult.isTrue === true,
      confidence: Math.min(100, Math.max(0, geminiResult.confidence)),
      explanation: geminiResult.explanation || 'No explanation provided',
      sources: Array.isArray(geminiResult.sources) ? geminiResult.sources : [],
      category: geminiResult.category || 'unverified',
    };
  } catch (error: any) {
    console.error('Error checking facts with Gemini:', error);
    return null;
  }
}

// Verify news using NewsAPI
export async function verifyWithNewsAPI(query: string): Promise<NewsVerification | null> {
  if (!NEWS_API_KEY) {
    console.warn('NewsAPI key not configured');
    return null;
  }

  try {
    const response = await axios.get(NEWS_API_URL, {
      params: {
        q: query,
        apiKey: NEWS_API_KEY,
        language: 'en',
        sortBy: 'relevancy',
        pageSize: 5,
      },
    });

    return {
      articles: response.data.articles?.map((article: any) => ({
        source: article.source.name,
        title: article.title,
        description: article.description,
        url: article.url,
        publishedAt: article.publishedAt,
      })) || [],
      totalResults: response.data.totalResults || 0,
    };
  } catch (error: any) {
    if (error.response?.status === 401 || error.response?.status === 403) {
      console.error('NewsAPI Error: Invalid API key or access denied.');
      console.error('Get a free API key at: https://newsapi.org/');
    } else {
      console.error('Error verifying with NewsAPI:', error);
    }
    return null;
  }
}

// Analyze text content comprehensively (HYBRID APPROACH)
export async function analyzeTextContent(text: string): Promise<VerificationResult> {
  const startTime = Date.now();

  try {
    // HYBRID FACT-CHECKING: Try Gemini first, then NewsAPI, then heuristics
    const geminiResult = await checkFactWithGemini(text);
    const newsData = await verifyWithNewsAPI(text);
    const factChecks = await checkFactWithGoogle(text); // Will fail but we try anyway

    // Calculate verification metrics
    const hasGeminiResult = geminiResult !== null;
    const hasFactChecks = factChecks.length > 0;
    const hasNews = newsData && newsData.totalResults > 0;

    let isReal = false;
    let confidence = 50;
    let credibilityScore = 50;
    let sourceReliability = 50;
    let highlights: string[] = [];
    let explanation = '';

    // Priority 1: Gemini AI (most flexible and powerful)
    if (hasGeminiResult) {
      isReal = geminiResult.isTrue;
      confidence = geminiResult.confidence;
      credibilityScore = geminiResult.isTrue ? geminiResult.confidence : 100 - geminiResult.confidence;
      sourceReliability = geminiResult.confidence;

      if (geminiResult.isTrue) {
        highlights = ['Verified by AI analysis', 'Appears credible', geminiResult.category === 'true' ? 'Factually accurate' : 'Likely true'];
      } else {
        highlights = ['Flagged by AI analysis', geminiResult.category === 'false' ? 'Factually false' : 'Questionable claim', 'Verification recommended'];
      }

      explanation = geminiResult.explanation;

      // Boost confidence if NewsAPI agrees
      if (hasNews) {
        const reputableSources = newsData.articles.filter(a =>
          ['Reuters', 'BBC', 'AP', 'NPR', 'PBS', 'Nature', 'Science'].some(source =>
            a.source.toLowerCase().includes(source.toLowerCase())
          )
        );

        if (reputableSources.length > 0) {
          confidence = Math.min(95, confidence + 10);
          credibilityScore = Math.min(95, credibilityScore + 10);
          highlights.push(`${reputableSources.length} reputable source(s) found`);
          explanation += ` Confirmed by ${reputableSources.length} reputable news source(s).`;
        }
      }
    }
    // Priority 2: Traditional Fact Check API (if somehow available)
    else if (hasFactChecks) {
      const ratings = factChecks.flatMap(fc =>
        fc.claimReview?.map(cr => cr.textualRating.toLowerCase()) || []
      );

      const positiveRatings = ratings.filter(r =>
        r.includes('true') || r.includes('correct') || r.includes('accurate') || r.includes('mostly true')
      );
      const negativeRatings = ratings.filter(r =>
        r.includes('false') || r.includes('misleading') || r.includes('incorrect') ||
        r.includes('pants on fire') || r.includes('mostly false')
      );

      if (negativeRatings.length > positiveRatings.length) {
        isReal = false;
        confidence = Math.min(95, 70 + (negativeRatings.length * 8));
        credibilityScore = Math.max(15, 40 - (negativeRatings.length * 15));
        highlights = ['Debunked by fact-checkers', 'Contains false claims', 'Multiple sources dispute this'];
        explanation = `This claim has been reviewed by ${factChecks.length} fact-checking organization(s) and rated as FALSE or misleading.`;
      } else if (positiveRatings.length > negativeRatings.length) {
        isReal = true;
        confidence = Math.min(95, 70 + (positiveRatings.length * 10));
        credibilityScore = Math.min(95, 70 + (positiveRatings.length * 12));
        highlights = ['Verified by fact-checkers', 'Credible sources confirm', 'Factual information'];
        explanation = `This claim has been verified by ${factChecks.length} fact-checking organization(s) and rated as TRUE.`;
      } else {
        isReal = false;
        confidence = 55;
        credibilityScore = 45;
        highlights = ['Mixed fact-check results', 'Conflicting information', 'Requires additional verification'];
        explanation = `This claim has been reviewed with mixed or unclear ratings from fact-checkers. Exercise caution.`;
      }

      sourceReliability = credibilityScore;
    }
    // Priority 3: NewsAPI + Heuristics
    else if (hasNews) {
      const articleCount = newsData.totalResults;
      const reputableSources = newsData.articles.filter(a =>
        ['Reuters', 'BBC', 'AP', 'NPR', 'PBS', 'Nature', 'Science', 'NASA', 'National Geographic'].some(source =>
          a.source.toLowerCase().includes(source.toLowerCase())
        )
      );

      // Analyze the actual claim text for known false claims
      const claimLower = text.toLowerCase();
      const isFlatEarthClaim = claimLower.includes('earth') &&
        (claimLower.includes('flat') || claimLower.includes('disc'));
      const isCommonConspiracy = claimLower.includes('earth') &&
        (claimLower.includes('donut') || claimLower.includes('square') ||
          claimLower.includes('cube') || claimLower.includes('hollow'));

      // Check for well-established scientific facts
      const isScientificFact = (claimLower.includes('earth') &&
        (claimLower.includes('round') || claimLower.includes('sphere') ||
          claimLower.includes('globe') || claimLower.includes('oblate spheroid'))) ||
        (claimLower.includes('gravity') && claimLower.includes('exist')) ||
        (claimLower.includes('sun') && claimLower.includes('center'));

      // Check if articles are CONFIRMING or DEBUNKING
      const titleAndDesc = newsData.articles.map(a =>
        `${a.title} ${a.description}`.toLowerCase()
      ).join(' ');

      const hasDebunkingKeywords = titleAndDesc.includes('debunk') ||
        titleAndDesc.includes('myth') ||
        titleAndDesc.includes('hoax') ||
        titleAndDesc.includes('conspiracy') ||
        titleAndDesc.includes('misinformation') ||
        titleAndDesc.includes('false claim') ||
        titleAndDesc.includes('pseudoscience');

      const hasConfirmingKeywords = titleAndDesc.includes('scientist') ||
        titleAndDesc.includes('research') ||
        titleAndDesc.includes('study shows') ||
        titleAndDesc.includes('evidence') ||
        titleAndDesc.includes('confirmed') ||
        titleAndDesc.includes('proven') ||
        titleAndDesc.includes('discovery');

      // Handle known conspiracy theories
      if (isFlatEarthClaim || isCommonConspiracy) {
        isReal = false;
        confidence = 95;
        credibilityScore = 10;
        sourceReliability = 15;
        highlights = ['Known conspiracy theory', 'Debunked by science', 'No credible evidence'];
        explanation = 'This is a widely debunked conspiracy theory with no scientific evidence.';
      }
      // Handle well-established scientific facts
      else if (isScientificFact) {
        isReal = true;
        confidence = 95;
        credibilityScore = 95;
        sourceReliability = 95;
        highlights = ['Established scientific fact', 'Widely accepted', 'Evidence-based'];
        explanation = 'This is a well-established scientific fact supported by extensive evidence and research.';
      }
      // Articles are debunking the claim
      else if (hasDebunkingKeywords && !hasConfirmingKeywords) {
        isReal = false;
        confidence = 80;
        credibilityScore = 25;
        sourceReliability = 35;
        highlights = ['Claim disputed by sources', 'Debunked as misinformation', 'Not credible'];
        explanation = `Found ${articleCount} articles, but they appear to be debunking or discussing this as misinformation.`;
      }
      // Multiple reputable sources OR scientific keywords
      else if (hasConfirmingKeywords || reputableSources.length >= 2) {
        isReal = true;
        confidence = Math.min(85, 65 + (reputableSources.length * 5));
        credibilityScore = Math.min(85, 60 + (reputableSources.length * 8));
        sourceReliability = Math.min(90, 65 + (reputableSources.length * 10));
        highlights = reputableSources.length > 0
          ? ['Covered by reputable sources', `${reputableSources.length} credible source(s)`, 'Appears legitimate']
          : ['Scientific/research coverage', 'Evidence-based discussion', 'Likely accurate'];
        explanation = reputableSources.length > 0
          ? `Found ${articleCount} articles, including ${reputableSources.length} from reputable sources. Claim appears legitimate.`
          : `Found ${articleCount} articles with scientific/research discussion. Claim appears to have evidence.`;
      }
      // One reputable source
      else if (reputableSources.length === 1) {
        isReal = true;
        confidence = 70;
        credibilityScore = 65;
        sourceReliability = 70;
        highlights = ['One reputable source found', 'Likely legitimate', 'Consider additional verification'];
        explanation = `Found coverage from 1 reputable source among ${articleCount} total articles. Claim appears legitimate but consider additional verification.`;
      }
      // Multiple articles but none reputable
      else if (articleCount > 5) {
        isReal = false;
        confidence = 55;
        credibilityScore = 50;
        sourceReliability = 45;
        highlights = ['Multiple sources found', 'Source credibility unknown', 'Verification recommended'];
        explanation = `Found ${articleCount} articles about this topic, but cannot verify credibility without reputable sources.`;
      }
      // Limited articles
      else {
        isReal = false;
        confidence = 60;
        credibilityScore = 40;
        sourceReliability = 35;
        highlights = ['Limited coverage', 'No reputable sources', 'Likely unverified'];
        explanation = `Limited news coverage found with no reputable sources. This claim appears unverified.`;
      }
    } else {
      // No verification data found at all
      isReal = false;
      confidence = 65;
      credibilityScore = 25;
      sourceReliability = 20;
      highlights = ['No verification found', 'Unverified claim', 'High risk of misinformation'];
      explanation = 'No AI analysis, fact-checking data, or credible news coverage found for this claim. Likely false or unverified.';
    }

    // Sentiment analysis (basic)
    const sentiment = analyzeTextSentiment(text);

    const processingTime = ((Date.now() - startTime) / 1000).toFixed(2) + 's';

    return {
      isReal,
      confidence,
      credibilityScore,
      sentiment,
      highlights,
      sourceReliability,
      processingTime,
      factChecks: hasFactChecks ? factChecks : undefined,
      relatedArticles: newsData || undefined,
      explanation,
    };
  } catch (error) {
    console.error('Error analyzing text:', error);
    throw error;
  }
}

// Basic sentiment analysis
function analyzeTextSentiment(text: string): 'positive' | 'negative' | 'neutral' {
  const lowerText = text.toLowerCase();
  const positiveWords = ['good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'success', 'win'];
  const negativeWords = ['bad', 'terrible', 'awful', 'horrible', 'disaster', 'fail', 'crisis', 'danger'];

  let positiveCount = 0;
  let negativeCount = 0;

  positiveWords.forEach(word => {
    if (lowerText.includes(word)) positiveCount++;
  });

  negativeWords.forEach(word => {
    if (lowerText.includes(word)) negativeCount++;
  });

  if (positiveCount > negativeCount) return 'positive';
  if (negativeCount > positiveCount) return 'negative';
  return 'neutral';
}

// Verify URL content (HYBRID APPROACH with Gemini AI)
export async function verifyURL(url: string): Promise<VerificationResult> {
  const startTime = Date.now();

  try {
    // Extract domain for verification
    const domain = new URL(url).hostname;

    // HYBRID VERIFICATION: Gemini + NewsAPI + Domain checking
    const geminiResult = await checkFactWithGemini(`Is this URL from a credible source? Domain: ${domain}, Full URL: ${url}`);
    const newsData = await verifyWithNewsAPI(domain);
    const factChecks = await checkFactWithGoogle(url);

    // Trusted domains list
    const trustedDomains = [
      'reuters.com', 'bbc.com', 'apnews.com', 'npr.org', 'pbs.org',
      'nytimes.com', 'washingtonpost.com', 'theguardian.com', 'economist.com',
      'nature.com', 'science.org', 'nasa.gov', 'nationalgeographic.com'
    ];

    const isTrustedDomain = trustedDomains.some(trusted => domain.includes(trusted));
    const hasGeminiResult = geminiResult !== null;

    let isReal = isTrustedDomain;
    let confidence = isTrustedDomain ? 85 : 50;
    let credibilityScore = isTrustedDomain ? 90 : 50;
    let sourceReliability = isTrustedDomain ? 95 : 50;
    let highlights: string[] = [];
    let explanation = '';

    // Priority 1: Gemini AI analysis
    if (hasGeminiResult) {
      isReal = geminiResult.isTrue;
      confidence = geminiResult.confidence;
      credibilityScore = geminiResult.isTrue ? geminiResult.confidence : 100 - geminiResult.confidence;
      sourceReliability = geminiResult.confidence;

      if (geminiResult.isTrue) {
        highlights = ['AI verified source', 'Appears credible', 'Domain analyzed'];
      } else {
        highlights = ['AI flagged source', 'Questionable credibility', 'Verify independently'];
      }

      explanation = geminiResult.explanation;

      // Boost confidence if it's a known trusted domain
      if (isTrustedDomain) {
        confidence = Math.min(95, confidence + 10);
        credibilityScore = Math.min(95, credibilityScore + 10);
        highlights.push('Well-known trusted domain');
        explanation += ` This domain is widely recognized as a reputable source.`;
      }
    }
    // Priority 2: Traditional fact-check (if available)
    else if (factChecks.length > 0) {
      const ratings = factChecks.flatMap(fc =>
        fc.claimReview?.map(cr => cr.textualRating.toLowerCase()) || []
      );
      const hasNegativeRating = ratings.some(r =>
        r.includes('false') || r.includes('misleading')
      );

      if (hasNegativeRating) {
        isReal = false;
        confidence = 80;
        credibilityScore = 30;
        highlights = ['Flagged by fact-checkers', 'Contains misinformation'];
        explanation = 'This URL has been flagged by fact-checking organizations.';
      }
    }
    // Priority 3: Domain reputation only
    else {
      if (isTrustedDomain) {
        highlights = ['Reputable source', 'Verified domain', 'Credible publisher'];
        explanation = `Source is from a well-known, reputable news organization.`;
      } else {
        highlights = ['Unknown source', 'Verify independently', 'Check credentials'];
        explanation = 'Source domain is not widely recognized. Verify information independently.';
      }
    }

    const processingTime = ((Date.now() - startTime) / 1000).toFixed(2) + 's';

    return {
      isReal,
      confidence,
      credibilityScore,
      sentiment: 'neutral',
      highlights,
      sourceReliability,
      processingTime,
      factChecks: factChecks.length > 0 ? factChecks : undefined,
      relatedArticles: newsData || undefined,
      explanation,
    };
  } catch (error) {
    console.error('Error verifying URL:', error);
    throw error;
  }
}

