import { Card, CardContent } from "@/components/ui/card";
import {
  Brain,
  Eye,
  BarChart3,
  Globe,
  Link2,
  Zap,
  Shield,
  Sparkles
} from "lucide-react";

const features = [
  {
    icon: Brain,
    title: "Gemini AI Analysis",
    description: "Advanced reasoning with Google's Gemini 2.5 Flash for intelligent credibility assessment and contextual fact-checking.",
    gradient: "from-primary via-primary-glow to-secondary",
  },
  {
    icon: Eye,
    title: "Multi-Modal Detection",
    description: "Comprehensive analysis across text, images, videos, and memes using specialized AI models for each content type.",
    gradient: "from-secondary via-accent to-primary",
  },
  {
    icon: BarChart3,
    title: "Credibility Scoring",
    description: "Transparent confidence metrics with source reliability analysis and detailed AI explanations for every verification.",
    gradient: "from-success via-success-glow to-secondary",
  },
  {
    icon: Globe,
    title: "NewsAPI Integration",
    description: "Real-time cross-referencing with Reuters, BBC, AP, and 50+ reputable global news sources and scientific journals.",
    gradient: "from-accent via-secondary to-primary",
  },
  {
    icon: Link2,
    title: "URL Verification",
    description: "Intelligent domain credibility evaluation, source reputation scoring, and automated content reliability checks.",
    gradient: "from-destructive via-destructive-glow to-primary",
  },
  {
    icon: Zap,
    title: "Hybrid Intelligence",
    description: "Multi-layered verification combining Gemini AI, NewsAPI data, and advanced heuristics for maximum accuracy.",
    gradient: "from-primary via-secondary to-accent",
  },
];

const FeaturesSection = () => {
  return (
    <section id="features" className="py-32 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-grid-white bg-[size:50px_50px] opacity-30" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-3xl" />

      <div className="container relative z-10 mx-auto px-6">
        {/* Section Header */}
        <div className="text-center max-w-4xl mx-auto mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 glass-card rounded-full mb-6">
            <Sparkles className="w-4 h-4 text-primary animate-pulse" />
            <span className="text-sm font-semibold text-primary">Advanced Capabilities</span>
          </div>
          <h2 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            <span className="text-gradient-primary">Next-Gen</span> Fact-Checking
          </h2>
          <p className="text-xl text-muted-foreground leading-relaxed">
            Powered by cutting-edge AI technology and trusted data sources for comprehensive verification
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-24">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="group glass-card border-0 hover:border-primary/20 transition-all duration-500 hover:scale-105 hover:shadow-hover cursor-pointer"
            >
              <CardContent className="p-8 relative">
                {/* Gradient Backdrop */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                {/* Feature Icon */}
                <div className="relative mb-6">
                  <div className={`inline-flex p-5 rounded-2xl bg-gradient-to-br ${feature.gradient} shadow-glow group-hover:shadow-hover transition-all duration-500 group-hover:scale-110 group-hover:rotate-3`}>
                    <feature.icon className="w-8 h-8 text-white drop-shadow-lg" />
                  </div>
                </div>

                {/* Feature Content */}
                <h3 className="text-2xl font-bold mb-4 group-hover:text-primary transition-colors duration-300">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>

                {/* Hover Accent */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-secondary to-accent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-b-2xl" />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Results Preview - Premium Design */}
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-3">
              See <span className="text-gradient-primary">Results</span> in Action
            </h3>
            <p className="text-muted-foreground">Real-time analysis with transparent confidence scoring</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Verified Result Card */}
            <Card className="glass-card border-success/30 hover:border-success/60 shadow-card hover:shadow-hover transition-all duration-500 group">
              <CardContent className="p-8">
                <div className="flex items-start gap-4 mb-6">
                  <div className="p-3 rounded-xl bg-success/20">
                    <Shield className="w-7 h-7 text-success" />
                  </div>
                  <div>
                    <div className="text-xl font-bold text-success mb-1">VERIFIED AUTHENTIC</div>
                    <div className="text-sm text-muted-foreground">High confidence verification</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-muted-foreground">Credibility Score</span>
                    <span className="text-lg font-bold text-success">96.4%</span>
                  </div>
                  <div className="relative w-full h-3 bg-muted/30 rounded-full overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-success to-success-glow h-3 rounded-full transition-all duration-1000 ease-out" style={{ width: '96.4%' }} />
                    <div className="absolute inset-0 bg-success/20 rounded-full animate-pulse" style={{ width: '96.4%' }} />
                  </div>
                  <div className="pt-3 space-y-2">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 bg-success rounded-full" />
                      <span>Source verified by AI</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 bg-success rounded-full" />
                      <span>Cross-referenced with Reuters, BBC</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 bg-success rounded-full" />
                      <span>No manipulation detected</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Fake Detected Card */}
            <Card className="glass-card border-destructive/30 hover:border-destructive/60 shadow-card hover:shadow-hover transition-all duration-500 group">
              <CardContent className="p-8">
                <div className="flex items-start gap-4 mb-6">
                  <div className="p-3 rounded-xl bg-destructive/20">
                    <Sparkles className="w-7 h-7 text-destructive" />
                  </div>
                  <div>
                    <div className="text-xl font-bold text-destructive mb-1">FAKE DETECTED</div>
                    <div className="text-sm text-muted-foreground">AI flagged misinformation</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-muted-foreground">False Probability</span>
                    <span className="text-lg font-bold text-destructive">99.1%</span>
                  </div>
                  <div className="relative w-full h-3 bg-muted/30 rounded-full overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-destructive to-destructive-glow h-3 rounded-full transition-all duration-1000 ease-out" style={{ width: '99.1%' }} />
                    <div className="absolute inset-0 bg-destructive/20 rounded-full animate-pulse" style={{ width: '99.1%' }} />
                  </div>
                  <div className="pt-3 space-y-2">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 bg-destructive rounded-full" />
                      <span>Misleading claims identified</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 bg-destructive rounded-full" />
                      <span>Unreliable source detected</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 bg-destructive rounded-full" />
                      <span>Emotional manipulation tactics found</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;