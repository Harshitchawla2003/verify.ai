import { Button } from "@/components/ui/button";
import { ArrowRight, Zap, Shield, Brain, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import heroImage from "@/assets/hero-verification.jpg";

const HeroSection = () => {
  const navigate = useNavigate();
  return (
    <section className="relative min-h-screen overflow-hidden">
      {/* Animated Grid Background */}
      <div className="absolute inset-0 bg-grid-white bg-[size:60px_60px]" />

      {/* Gradient Orbs */}
      <div className="absolute top-20 right-20 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '4s' }} />
      <div className="absolute bottom-20 left-20 w-96 h-96 bg-secondary/20 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '6s', animationDelay: '2s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent/10 rounded-full blur-3xl" />

      <div className="container relative z-10 mx-auto px-6 pt-32 pb-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Hero Content */}
          <div className="space-y-8">
            {/* Premium Badge */}
            <div className="inline-flex items-center gap-2 px-5 py-2.5 glass-card rounded-full border-success/30 hover:border-success/60 transition-all duration-300 group cursor-pointer">
              <Sparkles className="w-4 h-4 text-success animate-pulse" />
              <span className="text-sm font-semibold text-success">Advanced AI Technology</span>
              <div className="w-2 h-2 bg-success rounded-full animate-ping" />
            </div>

            {/* Dynamic Headline */}
            <div className="space-y-6">
              <h1 className="text-6xl lg:text-8xl font-bold leading-tight tracking-tight">
                <span className="text-gradient-primary text-glow">VeriFy.AI</span>
                <br />
                <span className="text-foreground/90">Truth in the</span>
                <br />
                <span className="text-muted-foreground/70">Digital Age</span>
              </h1>
              <p className="text-xl lg:text-2xl text-muted-foreground max-w-xl leading-relaxed">
                Next-generation <span className="text-primary font-semibold">AI-powered</span> fact verification.
                Analyze text, images, videos, and URLs with <span className="text-secondary font-semibold">real-time</span> credibility insights.
              </p>
            </div>

            {/* Feature Pills */}
            <div className="flex flex-wrap gap-3">
              <div className="flex items-center gap-2 px-4 py-2 glass-card rounded-full border-primary/20 hover:border-primary/40 transition-all group">
                <Brain className="w-4 h-4 text-primary group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium">Multi-Modal AI</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 glass-card rounded-full border-secondary/20 hover:border-secondary/40 transition-all group">
                <Zap className="w-4 h-4 text-secondary group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium">Instant Results</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 glass-card rounded-full border-success/20 hover:border-success/40 transition-all group">
                <Shield className="w-4 h-4 text-success group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium">98% Accuracy</span>
              </div>
            </div>

            {/* Premium CTA */}
            <div className="pt-4">
              <Button
                variant="hero"
                size="xl"
                className="group text-lg px-10 py-7 bg-gradient-primary hover:shadow-glow rounded-2xl border-0 transition-all duration-300 hover:scale-105"
                onClick={() => navigate('/verify')}
              >
                <Sparkles className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform" />
                Start Verifying Now
                <ArrowRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-2" />
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="pt-6 flex items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
                <span>Live AI Analysis</span>
              </div>
              <div className="w-px h-4 bg-border" />
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-primary" />
                <span>Privacy Focused</span>
              </div>
              <div className="w-px h-4 bg-border" />
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-secondary" />
                <span>Free to Use</span>
              </div>
            </div>
          </div>

          {/* Hero Visual */}
          <div className="relative lg:block hidden">
            {/* Main Image Card */}
            <div className="relative float">
              <div className="glass-card p-3 rounded-3xl shadow-hover border-primary/20 hover:border-primary/40 transition-all duration-500">
                <img
                  src={heroImage}
                  alt="AI fact verification dashboard"
                  className="w-full h-auto rounded-2xl shadow-lg"
                />
                {/* Scanning Effect */}
                <div className="absolute inset-0 rounded-3xl overflow-hidden pointer-events-none">
                  <div className="scan-line absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
                </div>
              </div>
            </div>

            {/* Floating Result Cards */}
            <div className="absolute -top-6 -right-6 glass-card p-5 rounded-2xl float border-success/30 hover:border-success/60 transition-all duration-300 group cursor-pointer" style={{ animationDelay: '0.5s' }}>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-success/20 flex items-center justify-center">
                  <Shield className="w-6 h-6 text-success" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-success">Verified Authentic</div>
                  <div className="text-xs text-muted-foreground mt-1">Confidence: 96.4%</div>
                </div>
              </div>
            </div>

            <div className="absolute -bottom-6 -left-6 glass-card p-5 rounded-2xl float border-destructive/30 hover:border-destructive/60 transition-all duration-300 group cursor-pointer" style={{ animationDelay: '1.5s' }}>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-destructive/20 flex items-center justify-center">
                  <Zap className="w-6 h-6 text-destructive" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-destructive">Fake Detected</div>
                  <div className="text-xs text-muted-foreground mt-1">Confidence: 99.1%</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;