import { Shield, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

const Header = () => {
  const navigate = useNavigate();
  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-primary/10">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Premium Logo */}
          <div
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => navigate('/')}
          >
            <div className="relative p-2.5 bg-gradient-primary rounded-xl shadow-glow group-hover:shadow-hover transition-all duration-300 group-hover:scale-110">
              <Shield className="w-6 h-6 text-white" />
              <div className="absolute -top-1 -right-1 w-3 h-3">
                <Sparkles className="w-3 h-3 text-success animate-pulse" />
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gradient-primary transition-all duration-300">
                VeriFy.AI
              </h1>
              <p className="text-xs text-muted-foreground">Next-Gen Fact Verification</p>
            </div>
          </div>

          {/* Premium CTA */}
          <Button
            variant="hero"
            size="sm"
            className="bg-gradient-primary hover:shadow-glow rounded-xl border-0 px-6 transition-all duration-300 hover:scale-105 group"
            onClick={() => navigate('/verify')}
          >
            <Sparkles className="w-4 h-4 mr-2 group-hover:rotate-12 transition-transform" />
            Start Verification
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;